"""
Central config for the local ML pipeline.
Edit SHEET_ID and SERVICE_ACCOUNT_JSON to match your setup (see README.md).

Every secret-like value below checks an environment variable FIRST, falling
back to the hardcoded local value if that variable isn't set. This is what
lets the exact same file work unmodified in two places: your Windows laptop
(no relevant env vars set, so it just uses whatever you typed in here), and
GitHub Actions (which injects real values from encrypted Secrets as env
vars — see .github/workflows/daily.yml). Neither setup requires touching
the other's code path.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
STATE_DIR = os.path.join(BASE_DIR, "state")

# --- Fill these in for local/Windows use ---
SHEET_ID = os.environ.get("PIPELINE_SHEET_ID", "PASTE_YOUR_GOOGLE_SHEET_ID_HERE")
SERVICE_ACCOUNT_JSON = os.environ.get(
    "PIPELINE_SERVICE_ACCOUNT_JSON_PATH",
    os.path.join(BASE_DIR, "service_account.json"),
)

SYMBOLS = ["NIFTY", "CRUDEOILM"]
TAB_KINDS = ["chain", "candles"]  # matches chain_<SYMBOL>_<DATE> / candles_<SYMBOL>_<DATE>

# --- GitHub Pages publishing (for mobile/anywhere dashboard access) ---
# See README for setup steps (create repo, enable Pages, generate token).
# Leave GITHUB_TOKEN as-is to skip publishing — the local dashboard.html
# still gets generated either way, just not pushed anywhere.
GITHUB_TOKEN = os.environ.get("PIPELINE_GITHUB_TOKEN", "PASTE_YOUR_GITHUB_PERSONAL_ACCESS_TOKEN_HERE")
GITHUB_REPO = os.environ.get("PIPELINE_GITHUB_REPO", "yourusername/your-repo-name")
GITHUB_PAGES_BRANCH = os.environ.get("PIPELINE_GITHUB_BRANCH", "main")
GITHUB_PAGES_URL = "https://yourusername.github.io/your-repo-name/"  # for your reference, not used programmatically

# --- Data-sufficiency thresholds, used by data_report.py ---
# These are deliberately conservative starting points, not a guarantee that
# this much data makes a model "good" — just a floor below which training
# anything is closer to noise-fitting than modeling. Worth revisiting once
# you have real experience with how this instrument's data behaves.
MIN_TRADING_DAYS_FOR_TRAINING = 20   # ~1 month of trading days
MIN_ROWS_PER_DAY_EXPECTED = 300      # sanity check — a day with far fewer rows suggests a partial/broken log
